package com.example.Teacher.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.Teacher.dto.StudentDto;
import com.example.Teacher.dto.StudyMaterialDto;
import com.example.Teacher.entities.Teacher;
import com.example.Teacher.service.TeacherService;

@RestController
@RequestMapping("/teachers")
public class TeacherController {
	
	
	
	@Autowired
	TeacherService teacherService;
	
	@PostMapping
	public ResponseEntity<Teacher> save(@RequestBody Teacher teacher){
		return new ResponseEntity<Teacher>(teacherService.save(teacher),HttpStatus.CREATED);
	}
	
	@GetMapping
	public ResponseEntity<List<Teacher>> findAll(){
		return new ResponseEntity<List<Teacher>>(teacherService.findAll(),HttpStatus.OK);
	}
	
	@GetMapping("/getTeacherById/{id}")
	public ResponseEntity<Teacher> findTeacherById(@PathVariable("id") long id){
		return new ResponseEntity<Teacher>(teacherService.findById(id),HttpStatus.OK);
	}
	
	@PutMapping("/updateTeacher/{id}")
	public ResponseEntity<Teacher> updateTeacherById(@PathVariable("id") long id , @RequestBody Teacher teacher){
		return new ResponseEntity<Teacher>(teacherService.updateTeacherById(id,teacher),HttpStatus.OK);
	}
	
	@DeleteMapping("/deleteTeacher/{id}")
	public ResponseEntity<String> deleteTeacherById(@PathVariable("id") long id){
		teacherService.deleteById(id);
		return new ResponseEntity<String>("Teacher Deleted Successfully",HttpStatus.OK);
	}
	
	@GetMapping("/studentbystandard/{standard}")
	public ResponseEntity<List<StudentDto>> getStududentByStandard(@PathVariable("standard")String standard){
		return new ResponseEntity<List<StudentDto>>(teacherService.findByStandard(standard),HttpStatus.OK);
	}
	
	@PostMapping("/addingstudymaterial")
	public ResponseEntity<StudyMaterialDto> addStudyMaterial(@RequestBody StudyMaterialDto studyMaterialDto){
		return new ResponseEntity<StudyMaterialDto>(teacherService.addStudyMaterial(studyMaterialDto),HttpStatus.CREATED);
	}

}
