package com.example.Teacher.service;

import java.util.List;

import com.example.Teacher.dto.StudentDto;
import com.example.Teacher.dto.StudyMaterialDto;
import com.example.Teacher.entities.Teacher;



public interface TeacherService {
	
	Teacher save(Teacher teacher);
	List<Teacher> findAll();
	Teacher findById(long id);
	Teacher updateTeacherById(long id,Teacher teacher);
	void deleteById(long id);
	
	List<StudentDto> findByStandard(String standard);
	
	StudyMaterialDto addStudyMaterial(StudyMaterialDto studyMaterialDto);
	
}
