package com.example.Teacher.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import com.example.Teacher.dao.TeacherRepository;
import com.example.Teacher.dto.StudentDto;
import com.example.Teacher.dto.StudyMaterialDto;
import com.example.Teacher.entities.Teacher;
import com.example.Teacher.service.StudentFeignClient;
import com.example.Teacher.service.StudyStreamFeignClient;
import com.example.Teacher.service.TeacherService;

@Service
public class TeacherServiceImpl implements TeacherService {
	
	@Autowired
	StudentFeignClient studentClient;
	
	@Autowired
	StudyStreamFeignClient studyStreamFeignClient;
	
	@Autowired
	TeacherRepository teacherRepository;

	@Override
	public Teacher save(Teacher teacher) {
		return teacherRepository.save(teacher);
	}
	
	@Override
	public List<Teacher> findAll() {
		return teacherRepository.findAll();
	}

	@Override
	public Teacher findById(long id) {
		return teacherRepository.findById(id).orElseThrow();
	}

	@Override
	public Teacher updateTeacherById(long id, Teacher teacher) {
		Teacher oldData = findById(id);
		oldData.setName(teacher.getName());
		oldData.setEmail(teacher.getEmail());
		oldData.setClassTeacherOf(teacher.getClassTeacherOf());
		oldData.setQualification(teacher.getQualification());
		oldData.setAddress(teacher.getAddress());
		return oldData;
	}

	@Override
	public void deleteById(long id) {
		Teacher teacher = findById(id);
		teacherRepository.delete(teacher);
	}
	
	public List<StudentDto> findByStandard(@PathVariable("standard") String standard){
		return studentClient.findByStandard(standard);
	}

	@Override
	public StudyMaterialDto addStudyMaterial(StudyMaterialDto studyMaterialDto) {
		return studyStreamFeignClient.save(studyMaterialDto);
	}

	
	
	

	

}
