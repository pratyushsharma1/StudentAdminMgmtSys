package com.example.Teacher.service;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.Teacher.dto.StudyMaterialDto;

@FeignClient (name = "StudyStream",url = "http://localhost:8084/studymaterials")
public interface StudyStreamFeignClient {
	
	@PostMapping
	StudyMaterialDto save(@RequestBody StudyMaterialDto studyMaterialDto);
}
