package com.example.Teacher.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.Teacher.entities.Homework;
import com.example.Teacher.service.HomeworkService;

@RestController
@RequestMapping("/homeworks")
public class HomeworkController {
	
	@Autowired
	HomeworkService homeworkService;
	
	@PostMapping
	public ResponseEntity<Homework> save(@RequestBody Homework homework){
		return new ResponseEntity<Homework>(homeworkService.save(homework),HttpStatus.CREATED);
	}
	
	@GetMapping
	public ResponseEntity<List<Homework>> findAll(){
		return new ResponseEntity<List<Homework>>(homeworkService.findAll(),HttpStatus.OK);
	}
	
	@GetMapping("/gethomeworkById/{id}")
	public ResponseEntity<Homework> findHomeworkById(@PathVariable("id") long id){
		return new ResponseEntity<Homework>(homeworkService.findById(id),HttpStatus.OK);
	}
	
	@PutMapping("/updateHomework/{id}")
	public ResponseEntity<Homework> updateHomeworkById(@PathVariable("id") long id , @RequestBody Homework homework){
		return new ResponseEntity<Homework>(homeworkService.updateHomeworkById(id,homework),HttpStatus.OK);
	}
	
	@DeleteMapping("/deleteHomework/{id}")
	public ResponseEntity<String> deleteHomeworkById(@PathVariable("id") long id){
		homeworkService.deleteById(id);
		return new ResponseEntity<String>("Homework Deleted Successfully",HttpStatus.OK);
	}

}
